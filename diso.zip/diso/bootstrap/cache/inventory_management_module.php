<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\InventoryManagement\\Providers\\InventoryManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\InventoryManagement\\Providers\\InventoryManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);