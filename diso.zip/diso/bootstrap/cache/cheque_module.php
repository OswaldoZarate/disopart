<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cheque\\Providers\\ChequeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cheque\\Providers\\ChequeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);